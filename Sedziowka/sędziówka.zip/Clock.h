#pragma once

#include <time.h>

int end_game_time ()
{
	return 0;
}

int time_left ()
{
	return 0;
}